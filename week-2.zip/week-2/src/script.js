document.addEventListener('DOMContentLoaded', function() {
    const header = document.querySelector('header');

    header.addEventListener('click', function() {
        header.style.backgroundColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
    });
});
